import Table from "../components/InfoCards/Table/Table";

export const infoCardsData = [
  {
    title:'Request for purchase',
    component:<Table/>
  },
  {
    title:'Upcoming Tasks',
  },
  {
    title:'Upcoming Events',
  },
  {
    title:'Net Income',
  },
]